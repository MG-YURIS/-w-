# dsh-session-delete v2

给 DeepSeek Harness（DSH）桌面端会话行的「⋯」菜单加一项**红色「删除对话」**，位置在「复制 Session ID」正下方。

- 删除进入 **Windows 系统回收站**，不是插件自己的目录。
- 回收站里显示的名称就是**对话标题**，没有 `session-` 前缀、没有 `.zstd` 后缀。
- 正在打开、正在跑模型的对话也能删：会先强制停止回合/子代理/任务，再释放会话写句柄。
- 原有菜单项（置顶、重命名、分叉、归档、复制 Session ID）全部保留，不修改 DSH 自身文件。

## 效果

```text
⋯ 菜单
  置顶会话
  重命名
  分叉会话
  归档会话          Ctrl+Shift+A
  复制 Session ID
  删除对话          ← 本插件，红色
```

- 第一次点击：变成「再次点击确认删除」，20 秒内有效。
- 第二次点击：按钮显示「正在停止并删除…」，Host 先停止该对话的工作，再把它送进回收站。
- 完成后页面自动刷新，侧栏里的这一行消失。

## 回收站里是什么样

删除后，Windows 回收站里会出现**一个以对话标题命名的文件夹**，例如：

```text
回收站
└─ 如何在此平台生成AI视频        ← 名称就是对话标题
   ├─ session.v4.jsonl.zstd      ← 原对话日志
   ├─ dsh-session-delete.json    ← 回档用的元数据
   └─ __subagents__\...          ← 这个对话的子代理日志（如果有）
```

- 标题里的 Windows 非法字符（`\ / : * ? " < > |`）会被替换为 `_`，这是文件系统限制。
- 同名对话重复删除时，Windows 会自动显示为 `标题 (2)`。
- 子代理日志被打包在同一个文件夹里，不会在会话列表里留下孤儿。

## 强制停止

删除时会按顺序执行：

1. `workspace/session-stop` 提供方停止该会话的回合、子代理、任务、定时任务；
2. 取消并等待 Agent 空闲；
3. flush 持久化缓冲；
4. 从 Agent / Session 实时存储中分离，触发 `session/disposed`，让持久化后端关闭写句柄；
5. 停止成功后才重命名目录并送入回收站。

如果第 4 步无法彻底分离，插件会返回 `session-busy` 并**保留文件**，不会在写句柄仍打开时硬删。

## 一键安装

1. **完全退出 DSH**（关闭窗口并右键托盘退出）。
2. 把 `安装包` 文件夹复制到目标电脑任意位置。
3. 双击 `安装包\安装.cmd`。
4. 重新打开 DSH，打开任意会话行的「⋯」菜单。

安装脚本会：

- 把插件复制到 `%USERPROFILE%\.dsh\profiles\<profile>\node_modules\dsh-session-delete`；
- 把 `dsh-session-delete` 追加到 profile 的 `dsh.profile.bundles`；
- 把 `dsh-session-delete-2.0.0.tgz` 放进 profile 的 `vendor` 并登记为文件依赖；
- 修改前自动备份 `package.json.bak-<时间>`。

## 卸载

1. 完全退出 DSH。
2. 双击 `安装包\卸载.cmd`。
3. 重新打开 DSH。

卸载只移除插件、依赖声明和 vendor 压缩包，不碰任何对话数据，也不会清空 Windows 回收站。

## 手动回档

插件不提供自动回档按钮。回档流程是：

1. 打开 Windows 回收站，找到以对话标题命名的文件夹，右键**还原**。
   - 它会回到 `%USERPROFILE%\.dsh\sessions\<工作区目录>\<对话标题>`。
   - 如果原位置不可用，Windows 可能还原到桌面；路径在哪都可以，下一步用实际路径。
2. **完全退出 DSH**。
3. 把还原后的文件夹直接拖到安装包里的 **`回档.cmd`** 上；或执行：

```bat
回档.cmd "C:\Users\w3141\.dsh\sessions\--D-deepseek-1--\如何在此平台生成AI视频"
```

4. 重新打开 DSH，对话回到原工作区。

`回档.cmd`（以及工作区里的 `sessions.py restore-path`）会：

- 读取文件夹里的 `dsh-session-delete.json`；
- 把标题文件夹改回 `session-<id>`；
- 把 `__subagents__` 里的子代理日志移回原位；
- 删除元数据文件；
- 把会话 id 加回 `workspace.json`（如原先归档/置顶则一并恢复）。

> 如果文件夹还在回收站里，`restore-path` 无法直接读取；必须先右键还原，再把还原后的路径交给它。

## 安全边界

- **回收站不可用时不会硬删**：插件会先检查该磁盘的 `$Recycle.Bin\<SID>`，不可用就中止并回滚。
- **Shell 调用失败会回滚**：删除前会在 `%USERPROFILE%\.dsh\trash\recycle-backup` 留一份临时副本，确认回收站里出现对应 `$I` 记录后才删除副本；失败则把文件搬回原位。
- **不碰 DSH 安装目录**，只操作 `%USERPROFILE%\.dsh` 下的会话目录、`workspace.json`、标题缓存和第三方 `session-map` 中的对应 id。
- 附件目录（`attachments`，按内容寻址、可能被多个会话共享）不清理。
- 旧版 v1 的插件回收站 `%USERPROFILE%\.dsh\trash\session-cleaner` 不会被迁移或删除；里面的内容仍可用旧 CLI 恢复。

## 已知限制

- Windows 回收站会按磁盘配额自动清理旧文件；重要对话不要长期只留在回收站。
- 标题中的非法字符会被替换，因此回收站名称可能和对话标题略有差异。
- 正在写的回合被强制中止时，该回合未完成的内容不会写入日志（这是“强制删除”的预期行为）。
- 子代理日志只包含 DSH 能通过目录发现的部分；外部提供方的子代理可能没有本地日志。

## 兼容性

在 DSH `0.2.1-rc.3` 上开发，并用隔离实例做过完整验证：

- 打开一个会话使其 `liveAgent/liveSession=true`；
- 通过插件删除，接口返回 `recycled:true`；
- 删除后 `liveAgent/liveSession=false`，目录进入 Windows 回收站且名称为标题；
- 从回收站还原后，`restore-path` 成功恢复目录和 `workspace.json` 索引。

`package.json` 声明 `engines.dsh >= 0.2.1-rc.2`。

## 开发与测试

```bat
node test/host.test.mjs
node test/client.test.mjs
python scripts/build_dist.py
```

- Host 测试覆盖：标题命名、强制分离、回收站失败回滚、子代理打包、非法标题、404。
- 客户端测试覆盖：slot 注册、两次点击、请求体、成功刷新、`session-busy` 提示、无 primitives 降级按钮。
