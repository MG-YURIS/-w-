# dsh-session-delete v2

A DSH sidebar plugin that adds a red **Delete conversation** row right below **Copy Session ID** in the session row's “…” menu.

- Deletes into the **real Windows Recycle Bin**, not an app-private trash.
- The recycled item is named exactly like the conversation (no `session-` prefix, no `.zstd` suffix).
- Force-stops a running conversation (turn, subagents, jobs) before deleting, so an open/stuck conversation no longer requires a DSH restart.
- Every shipped menu item and handler stays untouched.

## Menu

```text
… menu
  Pin conversation
  Rename
  Fork
  Archive conversation      Ctrl+Shift+A
  Copy Session ID
  Delete conversation        ← this plugin, red
```

First click arms the row (“Click again to confirm”), the second click stops the conversation and moves it to the Recycle Bin.

## What lands in the Recycle Bin

One folder named after the conversation:

```text
Recycle Bin
└─ How to generate AI video        ← conversation title
   ├─ session.v4.jsonl.zstd
   ├─ dsh-session-delete.json      ← restore metadata
   └─ __subagents__\...            ← child logs, if any
```

Windows-forbidden title characters are replaced with `_`. Duplicate titles get the usual Windows `(2)` suffix.

## Install

1. Fully quit DSH (window and tray).
2. Copy the `安装包` folder to the target machine.
3. Double-click `安装包\安装.cmd`.
4. Start DSH and open a session row's “…” menu.

## Restore

1. In the Windows Recycle Bin, right-click the title folder → **Restore**.
2. Fully quit DSH.
3. Drag the restored folder onto `回档.cmd` in the installer folder, or run:

```bat
回档.cmd "C:\Users\w3141\.dsh\sessions\--D-deepseek-1--\How to generate AI video"
```

4. Start DSH again.

`restore-path` reads `dsh-session-delete.json`, renames the folder back to `session-<id>`, moves child logs back, and re-adds the workspace entry.

## Safety

- If the volume has no usable Recycle Bin, deletion aborts and rolls back.
- A temporary copy under `%USERPROFILE%\.dsh\trash\recycle-backup` is kept until the Shell confirms the `$I` record; a failed recycle restores it.
- DSH installation files are never modified.
- Attachments are content-addressed and shared, so they are left alone.

## Compatibility

Developed against DSH `0.2.1-rc.3`; verified in an isolated instance with a live session: `liveAgent/liveSession` go from `true` to `false`, the session folder appears in the Recycle Bin under its title, and `restore-path` restores both the files and `workspace.json`.
